//! Tensor WASM Core
//! Kleine, deterministische Funktionen ohne Geheimnisse.

use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn compose_f32(left: &[f32], right: &[f32]) -> Result<Vec<f32>, JsValue> {
    if left.len() != right.len() {
        return Err(JsValue::from_str("Compose benötigt zwei gleich lange Wertfolgen."));
    }
    Ok(left.iter().zip(right.iter()).map(|(a, b)| (a + b) * 0.5).collect())
}

#[wasm_bindgen]
pub fn compose_bool_or(left: &[u8], right: &[u8]) -> Result<Vec<u8>, JsValue> {
    if left.len() != right.len() {
        return Err(JsValue::from_str("Compose benötigt zwei gleich lange Wertfolgen."));
    }
    Ok(left.iter().zip(right.iter()).map(|(a, b)| u8::from(*a != 0 || *b != 0)).collect())
}

#[wasm_bindgen]
pub fn shape_volume(dims: &[u32], limit: u32) -> Result<u32, JsValue> {
    let mut volume: u32 = 1;
    for dim in dims {
        if *dim == 0 {
            return Err(JsValue::from_str("Eine Dimension darf nicht 0 sein."));
        }
        volume = volume.checked_mul(*dim).ok_or_else(|| JsValue::from_str("Die Shape ist zu groß."))?;
        if volume > limit {
            return Err(JsValue::from_str("Die Shape überschreitet das vereinbarte Limit."));
        }
    }
    Ok(volume)
}
