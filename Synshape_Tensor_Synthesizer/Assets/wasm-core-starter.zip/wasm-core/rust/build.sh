#!/usr/bin/env sh
set -eu

# Voraussetzungen (einmalig):
# rustup target add wasm32-unknown-unknown
# cargo install wasm-pack

wasm-pack build \
  --target web \
  --release \
  --out-dir ../../wasm-dist/rust \
  --out-name tensor_wasm_core

echo "Rust-WASM erstellt in wasm-dist/rust/. Erst nach Prüfung gezielt ins Frontend integrieren."
