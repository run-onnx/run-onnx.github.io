# Tensor WASM Core — lokaler Startpunkt

Dieser Ordner enthält **zwei alternative Vorlagen** für einen späteren, kleinen Rechenkern. Er ist absichtlich nicht in den aktuellen Browser-Build eingebunden. Tensor bleibt funktional ohne WASM; die Vorlagen sind eine saubere Ausgangsbasis, wenn reale Messungen zeigen, dass Compose oder Kennzahlen aus dem JavaScript-Thread ausgelagert werden sollen.

## Auswahl

| Variante | Gut geeignet, wenn … | Ausgabe |
|---|---|---|
| `rust/` | TypeScript-Bindungen, Ergonomie und ein klassischer Web-WASM-Weg gewünscht sind | WASM plus `wasm-bindgen`-Wrapper |
| `zig/` | Ein sehr kleines freistehendes Modul mit wenigen C-ähnlichen Exporten gewünscht ist | einzelne `.wasm`-Datei |

Die Vorlagen enthalten nur nicht geheime, deterministische Mathematik: `compose_f32`, Boolean-Compose und Shape-Volumen. Sie sind kein Anti-Disassembler-System. Der richtige Einsatzrahmen steht in [`../dokuDisA.txt`](../dokuDisA.txt).

## Empfohlene Grenze

In WASM gehören kleine, gut testbare Kerne. In TypeScript bleiben UI, Speicher, Dateiauswahl, Codex-Text, Barrierefreiheit und Fehlerkommunikation. Geheimnisse und autoritative Regeln gehören nicht in den Browser.

## Quellen

1. [wasm-bindgen Guide](https://rustwasm.github.io/docs/wasm-bindgen/)
2. [Zig Language Reference — WebAssembly](https://ziglang.org/documentation/master/)
