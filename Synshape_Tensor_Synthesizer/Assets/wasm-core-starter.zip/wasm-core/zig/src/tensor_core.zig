// Tensor WASM Core für freistehende Zig-WASM-Builds.
// Keine Geheimnisse und keine UI-Logik in dieses Modul legen.

pub export fn compose_f32(left: [*]const f32, right: [*]const f32, out: [*]f32, len: usize) void {
    var index: usize = 0;
    while (index < len) : (index += 1) {
        out[index] = (left[index] + right[index]) * 0.5;
    }
}

pub export fn compose_bool_or(left: [*]const u8, right: [*]const u8, out: [*]u8, len: usize) void {
    var index: usize = 0;
    while (index < len) : (index += 1) {
        out[index] = if (left[index] != 0 or right[index] != 0) 1 else 0;
    }
}

pub export fn shape_volume(dims: [*]const u32, len: usize, limit: u32) u32 {
    var volume: u32 = 1;
    var index: usize = 0;
    while (index < len) : (index += 1) {
        if (dims[index] == 0) return 0;
        const multiplied = @mulWithOverflow(volume, dims[index]);
        if (multiplied[1] != 0 or multiplied[0] > limit) return 0;
        volume = multiplied[0];
    }
    return volume;
}
