#!/usr/bin/env sh
set -eu

mkdir -p ../../wasm-dist/zig
zig build-lib src/tensor_core.zig \
  -target wasm32-freestanding \
  -O ReleaseSmall \
  -rdynamic \
  -fno-entry \
  -femit-bin=../../wasm-dist/zig/tensor_core.wasm

echo "Zig-WASM erstellt in wasm-dist/zig/. Erst nach Prüfung gezielt ins Frontend integrieren."
