# Sensorfähige Graphansicht — Entscheidungsnotizen

Die Graphansicht wird **rein lokal im Browser** aufgebaut. Ihre physisch wirkenden Verbindungslinien werden bewusst als begrenzte 2D/2.5D-Seilsimulation im Canvas ausgeführt; das hält sie bei wenigen bis mittleren ONNX-Graphen ruhig, direkt und auf mobilen Geräten nachvollziehbar. WebGPU bleibt eine optionale Hintergrundschicht, ist aber keine Voraussetzung dafür, dass der Graph funktioniert.

| Entscheidung | Umsetzung in Tensor | Begründung |
| --- | --- | --- |
| Sensorzugriff | Ausschließlich nach explizitem Klick auf „Bewegung aktivieren“ | Orientierungs- und Bewegungssensoren benötigen in einigen Browsern eine Nutzerinteraktion für die Freigabe. |
| Berechtigungen | Orientation und Motion werden gemeinsam angefragt, wenn die statischen Berechtigungsmethoden vorhanden sind | Der Nutzer erhält nur einen klar benannten, auf die Graphinteraktion bezogenen Freigabeschritt. |
| Fallback | Maus-/Touch-Impuls und ruhige automatische Leinenbewegung | Desktop, nicht unterstützte Geräte und abgelehnte Freigaben behalten dieselbe verständliche Graphansicht. |
| Sensorabbildung | `gamma` beeinflusst die horizontale Zugrichtung; `beta` steuert die Tiefe/den Durchhang; lineare Beschleunigung liefert kurze Impulse | Die Abbildung folgt dem dokumentierten Gerätekoordinatenmodell, wird aber stark gedämpft und begrenzt. |
| Datenschutz | Keine Speicherung, Übertragung oder Profilbildung aus Sensordaten | Sensorwerte werden ausschließlich flüchtig als Interaktionssignal für die aktuell sichtbare Canvas-Animation verwendet. |

Die einschlägigen Standards beschreiben Orientation und Motion als Secure-Context-APIs. `requestPermission()` kann je nach Browser verfügbar sein und verlangt bei einem Prompt eine transiente Nutzeraktion; danach stehen `deviceorientation` und `devicemotion` über Ereignisse zur Verfügung.[1][2][3]

## References

[1]: https://developer.mozilla.org/en-US/docs/Web/API/DeviceOrientationEvent/requestPermission_static "MDN: DeviceOrientationEvent.requestPermission()"
[2]: https://developer.mozilla.org/en-US/docs/Web/API/Device_orientation_events/Detecting_device_orientation "MDN: Detecting device orientation"
[3]: https://www.w3.org/TR/orientation-event/ "W3C: Device Orientation and Motion"
