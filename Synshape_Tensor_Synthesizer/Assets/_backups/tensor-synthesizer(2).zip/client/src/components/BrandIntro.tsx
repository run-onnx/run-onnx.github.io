/**
 * Synshape brand contract: a short, spatial entrance lets the mark resolve before work begins.
 * Landscape and portrait imagery are deliberately separate so the first frame respects each canvas.
 */
import { ArrowRight, SkipForward } from "lucide-react";

interface BrandIntroProps {
  onComplete: () => void;
}

const logo = "/manus-storage/synshape-tensor-knot_0673d93c.png";

export default function BrandIntro({ onComplete }: BrandIntroProps) {
  return (
    <section className="brand-intro" role="dialog" aria-modal="true" aria-label="Synshape introduction">
      <div className="intro-grain" />
      <div className="intro-content">
        <div className="intro-meta"><span className="intro-pip" /> GESTURE-NATIVE TENSOR AUTHORING</div>
        <div className="intro-centerpiece">
          <img className="intro-mark" src={logo} alt="Synshape tensor knot" />
          <p className="intro-wordmark">SYN<span>SHAPE</span></p>
          <p className="intro-tagline">Draw a surface. Resolve the graph.</p>
        </div>
        <div className="intro-footer">
          <p><b>LOCAL-FIRST</b> / POINTER → TENSOR → ONNX</p>
          <button onClick={onComplete}><SkipForward size={14} /> Skip intro <ArrowRight size={14} /></button>
        </div>
      </div>
    </section>
  );
}

