/**
 * Signal Cartography implementation reminder: this is a low-key spatial instrument field.
 * The WebGL layer is intentionally subordinate to live tensor geometry and validation signals.
 */
import { useEffect, useRef } from "react";

const vertexSource = `#version 300 es
in vec2 a_position;
void main() { gl_Position = vec4(a_position, 0.0, 1.0); }
`;

const fragmentSource = `#version 300 es
precision highp float;
out vec4 outColor;
uniform vec2 u_resolution;
uniform float u_time;

float line(float position, float thickness) {
  return 1.0 - smoothstep(thickness, thickness + 0.004, abs(fract(position) - 0.5));
}

void main() {
  vec2 uv = gl_FragCoord.xy / u_resolution.xy;
  vec2 centered = uv - vec2(0.5);
  centered.x *= u_resolution.x / u_resolution.y;
  float fineGrid = max(line(uv.x * 22.0, 0.003), line(uv.y * 22.0, 0.003));
  float coarseGrid = max(line(uv.x * 5.5, 0.006), line(uv.y * 5.5, 0.006));
  float arc = smoothstep(0.003, 0.0, abs(length(centered - vec2(0.18, -0.03)) - 0.34));
  float drift = 0.5 + 0.5 * sin(u_time * 0.35 + centered.x * 11.0 + centered.y * 8.0);
  vec3 base = vec3(0.028, 0.043, 0.054);
  vec3 grid = vec3(0.18, 0.30, 0.36) * fineGrid * 0.055;
  grid += vec3(0.32, 0.50, 0.58) * coarseGrid * 0.045;
  grid += vec3(0.36, 0.89, 0.90) * arc * (0.055 + drift * 0.018);
  float vignette = smoothstep(1.15, 0.16, length(centered));
  outColor = vec4((base + grid) * (0.62 + vignette * 0.38), 1.0);
}
`;

function compile(gl: WebGL2RenderingContext, type: number, source: string) {
  const shader = gl.createShader(type)!;
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader) ?? "shader error");
  return shader;
}

export default function WebGLField() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const gl = canvas.getContext("webgl2", { alpha: false, antialias: false, powerPreference: "high-performance" });
    if (!gl) return;

    const program = gl.createProgram()!;
    gl.attachShader(program, compile(gl, gl.VERTEX_SHADER, vertexSource));
    gl.attachShader(program, compile(gl, gl.FRAGMENT_SHADER, fragmentSource));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) return;

    const buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const position = gl.getAttribLocation(program, "a_position");
    const resolution = gl.getUniformLocation(program, "u_resolution");
    const time = gl.getUniformLocation(program, "u_time");
    let frame = 0;

    const render = (milliseconds: number) => {
      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      const width = Math.floor(canvas.clientWidth * ratio);
      const height = Math.floor(canvas.clientHeight * ratio);
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
        gl.viewport(0, 0, width, height);
      }
      gl.useProgram(program);
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.enableVertexAttribArray(position);
      gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
      gl.uniform2f(resolution, width, height);
      gl.uniform1f(time, milliseconds / 1000);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      frame = requestAnimationFrame(render);
    };

    frame = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(frame);
      gl.deleteProgram(program);
      gl.deleteBuffer(buffer);
    };
  }, []);

  return <canvas ref={canvasRef} className="webgl-field" aria-hidden="true" />;
}

