/** Synshape brand contract: factual, compact provenance; never obscures the spatial workspace. */
import { ExternalLink, X } from "lucide-react";

interface AboutPanelProps { onClose: () => void; }

export default function AboutPanel({ onClose }: AboutPanelProps) {
  return (
    <div className="about-overlay" role="presentation" onMouseDown={onClose}>
      <section className="about-panel" role="dialog" aria-modal="true" aria-labelledby="about-title" onMouseDown={(event) => event.stopPropagation()}>
        <button className="about-close" onClick={onClose} aria-label="Close about panel"><X size={18} /></button>
        <p className="eyebrow">ABOUT / SYN-SHAPE 0.2</p>
        <h2 id="about-title">Spatial input,<br />typed computation.</h2>
        <p>Synshape is a browser-native tensor authoring instrument. It turns pointer telemetry into shape descriptors, resolves operation legality before export, and serializes the graph locally as ONNX.</p>
        <div className="about-rule" />
        <p className="about-spec">NO APPLICATION BACKEND<br />NO TELEMETRY EGRESS<br />RAW PROTOBUF EXPORT</p>
        <a className="about-credit" href="https://g.dev/avx" target="_blank" rel="noreferrer">Micha <span>|</span> g.dev/avx <ExternalLink size={13} /></a>
      </section>
    </div>
  );
}
