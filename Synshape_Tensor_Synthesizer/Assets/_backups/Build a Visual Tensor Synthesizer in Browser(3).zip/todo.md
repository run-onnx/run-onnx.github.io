# Tensor Synthesizer — Erweiterungsplan

- [x] Markt-, Namens- und Positionierungsrecherche zu visuellen ONNX-/Tensor-Werkzeugen dokumentieren.
- [x] Einen differenzierbaren Produktnamen und eine konkrete USP-Positionierung auswählen.
- [x] Ein vollständiges, responsive einsetzbares Marken- und Logopaket definieren und erzeugen.
- [x] Adaptive Intro-Sequenzen für Quer- und Hochformat umsetzen.
- [x] Vollbildmodus für den zentralen Tensor-Arbeitsbereich ergänzen.
- [x] About-Panel mit Micha-Attribution und Link zu https://g.dev/avx ergänzen.
- [x] Editierbare nD-Dimensionsformel und Knotenaktualisierung implementieren.
- [x] ONNX-Initialisierer importieren/exportieren und in die Raw-Protobuf-Serialisierung integrieren.
- [x] onnxruntime-web als optionale rein lokale Modellvalidierung integrieren.
- [x] README aktualisieren sowie Desktop-, Mobil- und Exportabläufe prüfen.

## Runtime-Ausbau

- [x] Browser- und ONNX-Laufzeitgrenzen für Direct-Buffer-Ausführung, Rehydration und Custom-Operatoren dokumentieren.
- [x] Ein lokales ONNX-Importformat mit explizit unterstütztem Teilumfang entwerfen.
- [x] Die visuelle Rehydration, eine Operator-Palette und den „First graph“-Guide implementieren.
- [x] Einen WebNN-priorisierten, WASM-fallbackenden In-Memory-Ausführungsloop implementieren.
- [x] Live-Telemetrie als fest typisierten Float32-Tensor in kompatible Laufzeitgraphen einspeisen.
- [x] Ein mathematisches Erweiterungsprotokoll für Kahan-, Feynman- und Born-Module implementieren.
- [x] Ehrliche browserseitige Schutzoptionen umsetzen und ihre Grenzen sichtbar dokumentieren.
- [x] README aktualisieren sowie Import-, Execution-, Telemetrie- und mobile Abläufe prüfen.
