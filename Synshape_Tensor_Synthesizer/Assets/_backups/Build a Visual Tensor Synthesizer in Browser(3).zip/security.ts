/**
 * Synshape protection boundary: standards-based encrypted interchange, never a claim of client-side anti-reversing.
 * Telemetry is deliberately not used as key material; browser RNG and a user-supplied passphrase are required.
 */
import { GraphState } from "./tensor";

const encoder = new TextEncoder();
const toBase64 = (bytes: Uint8Array) => btoa(Array.from(bytes, (value) => String.fromCharCode(value)).join(""));

export async function encryptedSynshapePackage(graph: GraphState, passphrase: string) {
  if (passphrase.length < 12) throw new Error("Use a passphrase with at least 12 characters.");
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const material = await crypto.subtle.importKey("raw", encoder.encode(passphrase), "PBKDF2", false, ["deriveKey"]);
  const key = await crypto.subtle.deriveKey({ name: "PBKDF2", salt, iterations: 210000, hash: "SHA-256" }, material, { name: "AES-GCM", length: 256 }, false, ["encrypt"]);
  const plaintext = encoder.encode(JSON.stringify({ format: "synshape.package/v1", graph, createdAt: new Date().toISOString() }));
  const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plaintext);
  return JSON.stringify({ format: "synshape.encrypted-package/v1", algorithm: "AES-256-GCM", kdf: "PBKDF2-SHA-256", iterations: 210000, salt: toBase64(salt), iv: toBase64(iv), ciphertext: toBase64(new Uint8Array(encrypted)) }, null, 2);
}

/** A non-security telemetry label; useful for trace readability, never key derivation. */
export async function telemetrySessionLabel(values: Float32Array) {
  const nonce = crypto.getRandomValues(new Uint8Array(16));
  const bytes = new Uint8Array(values.byteLength + nonce.length); bytes.set(new Uint8Array(values.buffer)); bytes.set(nonce, values.byteLength);
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
  return Array.from(digest.slice(0, 5), (value) => value.toString(16).padStart(2, "0")).join("").toUpperCase();
}
