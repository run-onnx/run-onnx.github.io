/** Synshape preset library: deliberate browser-local persistence for named graph states. */
import { GraphState } from "./tensor";

const storageKey = "synshape.preset-library/v1";
export interface SynshapePreset { id: string; name: string; savedAt: string; graph: GraphState; }

export function loadPresetLibrary(): SynshapePreset[] {
  try { const parsed = JSON.parse(window.localStorage.getItem(storageKey) ?? "[]"); return Array.isArray(parsed) ? parsed : []; }
  catch { return []; }
}

export function writePresetLibrary(presets: SynshapePreset[]) { window.localStorage.setItem(storageKey, JSON.stringify(presets)); }

export function createPreset(name: string, graph: GraphState): SynshapePreset {
  return { id: crypto.randomUUID(), name: name.trim().slice(0, 48) || "Untitled graph", savedAt: new Date().toISOString(), graph };
}
