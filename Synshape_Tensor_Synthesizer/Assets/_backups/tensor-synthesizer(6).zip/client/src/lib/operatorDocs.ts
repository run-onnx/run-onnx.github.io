import { Operator } from "./tensor";

export interface OperatorDoc { title: string; class: "ONNX STANDARD" | "SYNSHAPE SIDECAR"; rule: string; behavior: string; }

export const operatorDocs: Record<Operator, OperatorDoc> = {
  Add: { title: "Add", class: "ONNX STANDARD", rule: "Matching or broadcastable tensor dimensions.", behavior: "Element-wise addition resolves one output tensor." },
  MatMul: { title: "MatMul", class: "ONNX STANDARD", rule: "The left inner dimension must equal the right outer dimension.", behavior: "Matrix contraction produces a shape from the outer dimensions." },
  Concat: { title: "Concat", class: "ONNX STANDARD", rule: "Ranks match; non-concatenated axes agree.", behavior: "Joins values on the terminal axis." },
  Relu: { title: "Relu", class: "ONNX STANDARD", rule: "One Float32 input; output preserves its shape.", behavior: "Clamps negative values to zero." },
  Conv: { title: "Conv", class: "ONNX STANDARD", rule: "Input and kernel layout must be compatible.", behavior: "The current palette records a portable Conv route with its declared shape." },
  Invalid: { title: "Conflict", class: "SYNSHAPE SIDECAR", rule: "The selected route violates the active shape contract.", behavior: "Export and execution remain blocked until the route is corrected." },
};
