# Tensor — Erweiterungsplan

- [x] Den bestehenden ONNX-Encoder und die aktuelle Bedienlogik auf sichere Erweiterungspunkte prüfen.
- [x] Ein robustes, lokales ONNX-Protobuf-Leseformat für Modellheader, Graph, Tensoren, Operatoren und Metadaten festlegen.
- [x] Einen verständlichen Import-Inspektor mit Modellübersicht, Shape, Datentyp, Operatoren und Codex-Metadaten gestalten.
- [x] Zusätzliche Operatoren mit datentypabhängiger Verfügbarkeit und ONNX-Serialisierung ergänzen.
- [x] Eingabefelder für echte Tensorwerte, einschließlich Syntaxprüfung und Exportverwendung, integrieren.
- [x] Build, Import- und Exportpfad auf Desktop und Mobilgerät prüfen; die Erweiterung visuell sichern.

Der automatisierte Round-Trip-Test erzeugt ein Modell mit direkten Floatwerten, dem Operator `Tanh` und Codex-Metadaten. Anschließend liest der lokale Inspektor dasselbe Binärmodell wieder ein und bestätigt Shape, Werte, Graph-Operator und Metadaten. Die Oberfläche wurde zusätzlich auf Desktop und Mobilgerät geprüft.
