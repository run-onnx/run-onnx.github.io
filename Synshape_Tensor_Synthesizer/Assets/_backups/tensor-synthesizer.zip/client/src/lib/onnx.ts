/**
 * Signal Cartography implementation reminder: serialize the model as transparent
 * protobuf wire bytes — no network, no runtime protobuf dependency, no hidden work.
 */
import { GraphState, makeGraphIndex, TensorEdge, TensorNode } from "./tensor";

const textEncoder = new TextEncoder();

function concat(chunks: Uint8Array[]): Uint8Array {
  const length = chunks.reduce((total, chunk) => total + chunk.length, 0);
  const output = new Uint8Array(length);
  let offset = 0;
  chunks.forEach((chunk) => {
    output.set(chunk, offset);
    offset += chunk.length;
  });
  return output;
}

function varint(value: number): Uint8Array {
  const bytes: number[] = [];
  let current = Math.max(0, Math.floor(value));
  while (current > 127) {
    bytes.push((current & 127) | 128);
    current = Math.floor(current / 128);
  }
  bytes.push(current);
  return Uint8Array.from(bytes);
}

function fieldVarint(field: number, value: number): Uint8Array {
  return concat([varint(field << 3), varint(value)]);
}

function fieldBytes(field: number, bytes: Uint8Array): Uint8Array {
  return concat([varint((field << 3) | 2), varint(bytes.length), bytes]);
}

function fieldString(field: number, value: string): Uint8Array {
  return fieldBytes(field, textEncoder.encode(value));
}

function message(parts: Uint8Array[]): Uint8Array {
  return concat(parts);
}

// TensorShapeProto.Dimension: dim_value = 1
function shapeDimension(value: number): Uint8Array {
  return message([fieldVarint(1, value)]);
}

// TensorShapeProto: dim = 1 repeated
function tensorShape(shape: number[]): Uint8Array {
  return message(shape.map((dimension) => fieldBytes(1, shapeDimension(dimension))));
}

// TypeProto.Tensor: elem_type = 1 (FLOAT), shape = 2
function tensorType(shape: number[]): Uint8Array {
  const tensor = message([fieldVarint(1, 1), fieldBytes(2, tensorShape(shape))]);
  return message([fieldBytes(1, tensor)]);
}

// ValueInfoProto: name = 1, type = 2
function valueInfo(name: string, shape: number[]): Uint8Array {
  return message([fieldString(1, name), fieldBytes(2, tensorType(shape))]);
}

// AttributeProto: name = 1, i = 3, type = 20 (INT = 2)
function integerAttribute(name: string, value: number): Uint8Array {
  return message([fieldString(1, name), fieldVarint(3, value), fieldVarint(20, 2)]);
}

// NodeProto: input = 1, output = 2, name = 3, op_type = 4, attribute = 5
function operationNode(edge: TensorEdge, sourceValue: string, basisValue: string): Uint8Array {
  const attributes = edge.op === "Concat" ? [fieldBytes(5, integerAttribute("axis", Math.max(0, (edge.outputShape?.length ?? 1) - 1)))] : [];
  return message([
    fieldString(1, sourceValue),
    fieldString(1, basisValue),
    fieldString(2, edge.to),
    fieldString(3, `op_${edge.id.slice(0, 8)}`),
    fieldString(4, edge.op),
    ...attributes,
  ]);
}

function orderedValidEdges(graph: GraphState): TensorEdge[] {
  const index = makeGraphIndex(graph);
  const valid = graph.edges.filter((edge) => edge.valid);
  const incoming = new Map<string, TensorEdge>();
  valid.forEach((edge) => incoming.set(edge.to, edge));
  const ordered: TensorEdge[] = [];
  const visited = new Set<string>();

  const visit = (nodeId: string) => {
    const edge = incoming.get(nodeId);
    if (!edge || visited.has(edge.id)) return;
    visit(edge.from);
    visited.add(edge.id);
    ordered.push(edge);
  };

  index.nodes.forEach((_, nodeId) => visit(nodeId));
  return ordered;
}

function resolvedShape(node: TensorNode, incoming: Map<string, TensorEdge>): number[] {
  return incoming.get(node.id)?.outputShape ?? node.shape;
}

/**
 * Produces a valid ONNX ModelProto with Float tensor inputs and inferred operation nodes.
 * A target node acts as the operation's browser-visible operand basis; its resolved value
 * becomes the output of the incoming operation, allowing a subsequent connection to form a DAG.
 */
export function buildOnnxModel(graph: GraphState): Uint8Array {
  const invalid = graph.edges.find((edge) => !edge.valid);
  if (invalid) throw new Error(`Cannot export while an invalid connection exists: ${invalid.reason ?? "shape conflict"}`);

  const index = makeGraphIndex(graph);
  const edges = orderedValidEdges(graph);
  const incoming = new Map<string, TensorEdge>();
  edges.forEach((edge) => incoming.set(edge.to, edge));
  const nodes = edges.map((edge) => {
    const sourceName = edge.from;
    const targetBasis = `${edge.to}__basis`;
    return fieldBytes(1, operationNode(edge, sourceName, targetBasis));
  });

  const inputs = graph.nodes.flatMap((node) => {
    const isDerived = incoming.has(node.id);
    const name = isDerived ? `${node.id}__basis` : node.id;
    return [fieldBytes(11, valueInfo(name, node.shape))];
  });

  const terminalNodes = graph.nodes.filter((node) => !(index.outgoing.get(node.id)?.some((edge) => edge.valid)));
  const outputs = (terminalNodes.length ? terminalNodes : graph.nodes).map((node) =>
    fieldBytes(12, valueInfo(node.id, resolvedShape(node, incoming))),
  );

  // GraphProto: node = 1, name = 2, input = 11, output = 12
  const graphProto = message([
    ...nodes,
    fieldString(2, "tensor_synthesizer_graph"),
    ...inputs,
    ...outputs,
  ]);

  // OperatorSetIdProto: version = 2. Empty domain selects the standard ai.onnx domain.
  const opsetImport = message([fieldVarint(2, 18)]);
  // ModelProto: ir_version = 1, producer_name = 2, producer_version = 3, graph = 7, opset_import = 8
  return message([
    fieldVarint(1, 10),
    fieldString(2, "TensorSynthesizer"),
    fieldString(3, "0.1.0-browser"),
    fieldBytes(7, graphProto),
    fieldBytes(8, opsetImport),
  ]);
}

export function downloadBytes(bytes: Uint8Array, filename: string, type: string) {
  const blob = new Blob([bytes], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

export function downloadOnnx(graph: GraphState) {
  downloadBytes(buildOnnxModel(graph), "tensor-synthesis.onnx", "application/octet-stream");
}

