/**
 * Signal Cartography implementation reminder: an instrument-console perimeter frames a full spatial stage.
 * Lime means valid/actionable, cyan maps structure, and coral exposes mathematical incompatibility.
 */
import { useMemo, useState } from "react";
import {
  Box,
  Braces,
  CircleAlert,
  CircleCheck,
  Download,
  GitFork,
  MousePointer2,
  Network,
  Plus,
  RotateCcw,
  Save,
  Sparkles,
  Trash2,
  Waves,
} from "lucide-react";
import { toast } from "sonner";
import GraphCanvas from "@/components/GraphCanvas";
import WebGLField from "@/components/WebGLField";
import { Button } from "@/components/ui/button";
import { downloadBytes, downloadOnnx } from "@/lib/onnx";
import {
  createDemoGraph,
  createEdge,
  deriveTensorFromStroke,
  DrawMode,
  formatShape,
  GraphState,
  InteractionTool,
  labelForMode,
  makeGraphIndex,
  summarizeTelemetry,
  TelemetrySample,
  TensorNode,
  wouldCreateCycle,
} from "@/lib/tensor";

const canvasBackdrop = "/manus-storage/tensor-field-atlas_6c6cbccc.jpg";
const projectionTexture = "/manus-storage/tensor-projection-surface_e47d3b6e.jpg";
const telemetryTexture = "/manus-storage/telemetry-wavefield_49d54ca4.jpg";
const ragTexture = "/manus-storage/rag-node-microcell_188bfdc6.jpg";
const logoTexture = "/manus-storage/tensor-knot-logo_c2e6b060.png";

const drawModes: { value: DrawMode; label: string; hint: string; icon: typeof Waves }[] = [
  { value: "line", label: "1D line", hint: "[batch, length]", icon: Waves },
  { value: "surface", label: "2D surface", hint: "[batch, height, width]", icon: Braces },
  { value: "volume", label: "3D volume", hint: "[batch, depth, h, w]", icon: Box },
  { value: "nd", label: "nD projection", hint: "[batch, …custom]", icon: Sparkles },
  { value: "rag", label: "micro-RAG", hint: "[1, latent]", icon: Network },
];

const tools: { value: InteractionTool; label: string; icon: typeof MousePointer2 }[] = [
  { value: "draw", label: "Draw", icon: Plus },
  { value: "select", label: "Select", icon: MousePointer2 },
  { value: "connect", label: "Route", icon: GitFork },
];

function downloadPreset(graph: GraphState) {
  const preset = JSON.stringify(
    {
      version: "0.1.0",
      createdAt: new Date().toISOString(),
      graph,
    },
    null,
    2,
  );
  downloadBytes(new TextEncoder().encode(preset), "tensor-synthesis.preset.json", "application/json");
}

export default function Home() {
  const [graph, setGraph] = useState<GraphState>(() => createDemoGraph());
  const [tool, setTool] = useState<InteractionTool>("draw");
  const [drawMode, setDrawMode] = useState<DrawMode>("surface");
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>("surface-input");
  const [liveSample, setLiveSample] = useState<TelemetrySample>({ x: 0, y: 0, pressure: 0.5, velocity: 0, time: 0 });

  const graphIndex = useMemo(() => makeGraphIndex(graph), [graph]);
  const selectedNode = selectedNodeId ? graphIndex.nodes.get(selectedNodeId) ?? null : null;
  const invalidEdges = graph.edges.filter((edge) => !edge.valid);
  const validEdges = graph.edges.filter((edge) => edge.valid);
  const hasExportableGraph = graph.nodes.length > 0 && invalidEdges.length === 0;
  const liveTelemetry = useMemo(() => summarizeTelemetry([liveSample]), [liveSample]);

  const addNode = (samples: TelemetrySample[]) => {
    const position = {
      x: samples.reduce((total, sample) => total + sample.x, 0) / samples.length,
      y: samples.reduce((total, sample) => total + sample.y, 0) / samples.length,
    };
    const descriptor = deriveTensorFromStroke(drawMode, samples);
    const node: TensorNode = {
      ...descriptor,
      id: crypto.randomUUID(),
      label: labelForMode(drawMode, graph.nodes.length + 1),
      position,
    };
    setGraph((previous) => ({ ...previous, nodes: [...previous.nodes, node] }));
    setSelectedNodeId(node.id);
    toast.success(`${node.label} resolved`, { description: `${formatShape(node.shape)} from ${node.telemetry.sampleCount} pointer samples.` });
  };

  const connect = (sourceId: string, targetId: string) => {
    if (wouldCreateCycle(graph, sourceId, targetId)) {
      toast.error("Cycle blocked", { description: "The browser graph remains a directed acyclic graph." });
      return;
    }
    const source = graphIndex.nodes.get(sourceId);
    const target = graphIndex.nodes.get(targetId);
    if (!source || !target) return;
    const edge = createEdge(source, target, graph);
    setGraph((previous) => ({ ...previous, edges: [...previous.edges, edge] }));
    setSelectedNodeId(targetId);
    if (edge.valid) toast.success(`${edge.op} inferred`, { description: `${formatShape(edge.outputShape ?? [])} output shape.` });
    else toast.error("Connection conflict", { description: edge.reason });
  };

  const moveNode = (nodeId: string, position: { x: number; y: number }) => {
    setGraph((previous) => ({
      ...previous,
      nodes: previous.nodes.map((node) => (node.id === nodeId ? { ...node, position } : node)),
    }));
  };

  const deleteSelected = () => {
    if (!selectedNodeId) return;
    setGraph((previous) => ({
      nodes: previous.nodes.filter((node) => node.id !== selectedNodeId),
      edges: previous.edges.filter((edge) => edge.from !== selectedNodeId && edge.to !== selectedNodeId),
    }));
    setSelectedNodeId(null);
    toast.message("Node removed from graph");
  };

  const exportGraph = () => {
    try {
      downloadOnnx(graph);
      toast.success("ONNX binary serialized", { description: "A raw local .onnx download was generated without a network request." });
    } catch (error) {
      toast.error("Export blocked", { description: error instanceof Error ? error.message : "Unexpected serializer error." });
    }
  };

  return (
    <main className="synth-app">
      <div className="workspace-backdrop" style={{ backgroundImage: `linear-gradient(90deg, rgba(5,14,19,.92), rgba(5,14,19,.68)), url(${canvasBackdrop})` }} />
      <header className="topbar">
        <div className="brand-lockup">
          <img className="brand-mark" src={logoTexture} alt="" />
          <div>
            <p className="eyebrow">BROWSER-NATIVE / WEBGL</p>
            <h1>Tensor Synthesizer</h1>
          </div>
        </div>
        <div className="topbar-readouts">
          <span className="readout"><span className="status-dot" /> MEMORY DAG</span>
          <span className="readout mono">{graph.nodes.length} NODES / {validEdges.length} OPS</span>
          <span className={`readout validator ${invalidEdges.length ? "invalid" : "valid"}`}>
            {invalidEdges.length ? <CircleAlert size={13} /> : <CircleCheck size={13} />}
            {invalidEdges.length ? `${invalidEdges.length} CONFLICT${invalidEdges.length > 1 ? "S" : ""}` : "GRAPH VALID"}
          </span>
        </div>
        <div className="topbar-actions">
          <Button variant="outline" className="instrument-button" onClick={() => downloadPreset(graph)}>
            <Save size={15} /> Save preset
          </Button>
          <Button className="export-button" disabled={!hasExportableGraph} onClick={exportGraph}>
            <Download size={16} /> Export ONNX
          </Button>
        </div>
      </header>

      <aside className="left-rail" aria-label="Tensor drawing controls">
        <section className="rail-section">
          <p className="rail-label">01 / SYNTHESIZE</p>
          <div className="shape-stack">
            {drawModes.map((mode) => {
              const Icon = mode.icon;
              return (
                <button
                  key={mode.value}
                  className={`shape-control ${drawMode === mode.value ? "active" : ""}`}
                  onClick={() => { setDrawMode(mode.value); setTool("draw"); }}
                >
                  <Icon size={15} />
                  <span><strong>{mode.label}</strong><small>{mode.hint}</small></span>
                </button>
              );
            })}
          </div>
        </section>

        <section className="rail-section interaction-section">
          <p className="rail-label">02 / INTERACT</p>
          <div className="tool-row">
            {tools.map((item) => {
              const Icon = item.icon;
              return (
                <button key={item.value} className={`tool-button ${tool === item.value ? "active" : ""}`} onClick={() => setTool(item.value)}>
                  <Icon size={15} /><span>{item.label}</span>
                </button>
              );
            })}
          </div>
          <p className="tool-instruction">
            {tool === "draw" && `Draw on the field to resolve a ${drawMode === "rag" ? "micro-RAG" : drawMode} tensor.`}
            {tool === "select" && "Drag a node to reposition its nD projection."}
            {tool === "connect" && "Drag from one node toward another to infer an operator."}
          </p>
        </section>

        <section className="rail-section rail-actions">
          <button className="quiet-action" onClick={() => { setGraph(createDemoGraph()); setSelectedNodeId("surface-input"); toast.message("Reference graph restored"); }}><RotateCcw size={14} /> Reset demo</button>
          <button className="quiet-action danger" onClick={() => { setGraph({ nodes: [], edges: [] }); setSelectedNodeId(null); }}><Trash2 size={14} /> Clear graph</button>
        </section>
      </aside>

      <section className="spatial-stage" aria-label="Tensor spatial field">
        <WebGLField />
        <div className="reticle reticle-a" aria-hidden="true" />
        <div className="reticle reticle-b" aria-hidden="true" />
        <GraphCanvas
          nodes={graph.nodes}
          edges={graph.edges}
          selectedNodeId={selectedNodeId}
          tool={tool}
          drawMode={drawMode}
          onStrokeComplete={addNode}
          onSelect={setSelectedNodeId}
          onConnect={connect}
          onMoveNode={moveNode}
          onTelemetry={setLiveSample}
        />
        <div className="stage-hint">
          <span className="stage-index">{tool === "connect" ? "ROUTE MODE" : `${drawMode.toUpperCase()} MODE`}</span>
          <p>{tool === "connect" ? "Draw a hypothesis across two tensor ports." : "Pointer telemetry resolves dimensions when the stroke ends."}</p>
        </div>
        <div className="stage-axis x-axis" aria-hidden="true"><span>X / SPATIAL</span></div>
        <div className="stage-axis y-axis" aria-hidden="true"><span>Y / PRESSURE</span></div>
      </section>

      <aside className="right-inspector" aria-label="Graph inspector">
        <section className="inspector-header">
          <p className="rail-label">03 / INSPECT</p>
          <h2>{selectedNode ? selectedNode.label : "NO SELECTION"}</h2>
          <span className={`node-kind ${selectedNode?.kind === "rag" ? "rag" : ""}`}>{selectedNode?.kind === "rag" ? "MICRO-RAG" : "FLOAT TENSOR"}</span>
        </section>

        {selectedNode ? (
          <>
            <section className="shape-inspector" style={{ backgroundImage: `linear-gradient(90deg, rgba(11,27,34,.98), rgba(11,27,34,.50)), url(${selectedNode.kind === "rag" ? ragTexture : projectionTexture})` }}>
              <p>DECLARED SHAPE</p>
              <strong>{formatShape(selectedNode.shape)}</strong>
              <div className="dimension-rail">
                {selectedNode.shape.map((dimension, index) => <span key={`${dimension}-${index}`} style={{ height: `${Math.max(22, Math.min(54, dimension / 3))}px` }}><i />{dimension}</span>)}
              </div>
              <div className="shape-facts"><span>RANK <b>{selectedNode.shape.length}</b></span><span>TYPE <b>F32</b></span></div>
            </section>

            <section className="telemetry-card">
              <div className="section-title"><span>STROKE TELEMETRY</span><span className="live-word">LIVE</span></div>
              <div className="telemetry-grid">
                <div><small>SAMPLES</small><strong>{selectedNode.telemetry.sampleCount}</strong></div>
                <div><small>PRESSURE</small><strong>{selectedNode.telemetry.pressure.toFixed(2)}</strong></div>
                <div><small>VELOCITY</small><strong>{selectedNode.telemetry.velocity.toFixed(2)}</strong></div>
                <div><small>PATH</small><strong>{selectedNode.telemetry.pathLength.toFixed(2)}</strong></div>
              </div>
            </section>
            <button className="delete-node" onClick={deleteSelected}><Trash2 size={14} /> Remove selected node</button>
          </>
        ) : (
          <div className="empty-inspector"><Box size={24} /><p>Draw a shape to inspect its declared tensor geometry.</p></div>
        )}

        <section className="validator-panel">
          <div className="section-title"><span>LIVE SHAPE VALIDATOR</span><span className="mono">{graph.edges.length} ROUTES</span></div>
          <div className="validation-list">
            {!graph.edges.length && <p className="empty-validation">No routes to validate.</p>}
            {graph.edges.map((edge) => {
              const source = graphIndex.nodes.get(edge.from);
              const target = graphIndex.nodes.get(edge.to);
              return (
                <div key={edge.id} className={`validation-item ${edge.valid ? "ok" : "bad"}`}>
                  {edge.valid ? <CircleCheck size={14} /> : <CircleAlert size={14} />}
                  <div><strong>{source?.label} <em>→</em> {target?.label}</strong><span>{edge.valid ? `${edge.op} · ${formatShape(edge.outputShape ?? [])}` : edge.reason}</span></div>
                </div>
              );
            })}
          </div>
        </section>
      </aside>

      <footer className="telemetry-strip" style={{ backgroundImage: `linear-gradient(90deg, rgba(7,18,23,.92), rgba(7,18,23,.72)), url(${telemetryTexture})` }}>
        <div className="telemetry-title"><span className="pulse-dot" /> POINTER SENSORIK</div>
        <div className="sensor-readout"><small>X</small><strong>{liveSample.x.toFixed(3)}</strong></div>
        <div className="sensor-readout"><small>Y</small><strong>{liveSample.y.toFixed(3)}</strong></div>
        <div className="sensor-readout"><small>PRESSURE</small><strong>{liveTelemetry.pressure.toFixed(2)}</strong></div>
        <div className="sensor-readout"><small>VELOCITY</small><strong>{liveTelemetry.velocity.toFixed(2)}</strong></div>
        <p>Pointer / touch / pen samples remain browser-local. No server path.</p>
      </footer>
    </main>
  );
}

