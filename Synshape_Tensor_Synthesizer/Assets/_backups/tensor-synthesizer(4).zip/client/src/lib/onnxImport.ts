/**
 * Synshape import boundary: a small, explicit ONNX protobuf reader rehydrates the portable subset.
 * Unknown operators remain reported rather than silently coerced into an executable graph.
 */
import { GraphState, Operator, TensorEdge, TensorInitializer, TensorNode } from "./tensor";

type WireField = { field: number; wire: number; value: number | Uint8Array };
const text = new TextDecoder();

function readVarint(bytes: Uint8Array, offset: number): [number, number] {
  let value = 0; let multiplier = 1; let cursor = offset;
  while (cursor < bytes.length) { const byte = bytes[cursor++]; value += (byte & 127) * multiplier; if (!(byte & 128)) return [value, cursor]; multiplier *= 128; }
  throw new Error("Truncated protobuf varint.");
}

function fields(bytes: Uint8Array): WireField[] {
  const output: WireField[] = []; let cursor = 0;
  while (cursor < bytes.length) {
    const [tag, tagged] = readVarint(bytes, cursor); cursor = tagged;
    const field = tag >> 3; const wire = tag & 7;
    if (wire === 0) { const [value, next] = readVarint(bytes, cursor); output.push({ field, wire, value }); cursor = next; }
    else if (wire === 2) { const [length, next] = readVarint(bytes, cursor); const end = next + length; if (end > bytes.length) throw new Error("Truncated protobuf bytes."); output.push({ field, wire, value: bytes.slice(next, end) }); cursor = end; }
    else throw new Error(`Unsupported protobuf wire type ${wire}.`);
  }
  return output;
}
const firstBytes = (list: WireField[], field: number) => list.find((item) => item.field === field && item.value instanceof Uint8Array)?.value as Uint8Array | undefined;
const strings = (list: WireField[], field: number) => list.filter((item) => item.field === field && item.value instanceof Uint8Array).map((item) => text.decode(item.value as Uint8Array));

function parseShape(bytes: Uint8Array): number[] {
  const tensor = firstBytes(fields(bytes), 1); if (!tensor) return [];
  const shape = firstBytes(fields(tensor), 2); if (!shape) return [];
  return fields(shape).filter((item) => item.field === 1 && item.value instanceof Uint8Array).map((item) => {
    const dimension = fields(item.value as Uint8Array).find((part) => part.field === 1);
    return typeof dimension?.value === "number" ? dimension.value : 1;
  });
}
function parseValueInfo(bytes: Uint8Array) { const list = fields(bytes); return { name: text.decode(firstBytes(list, 1) ?? new Uint8Array()), shape: parseShape(firstBytes(list, 2) ?? new Uint8Array()) }; }
function parseInitializer(bytes: Uint8Array): TensorInitializer {
  const list = fields(bytes); const shape = list.filter((item) => item.field === 1 && typeof item.value === "number").map((item) => item.value as number);
  const raw = firstBytes(list, 4) ?? new Uint8Array(); const values: number[] = []; const view = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
  for (let index = 0; index + 3 < raw.byteLength; index += 4) values.push(view.getFloat32(index, true));
  return { id: crypto.randomUUID(), name: text.decode(firstBytes(list, 8) ?? new Uint8Array()), shape, values };
}
function parseNode(bytes: Uint8Array) { const list = fields(bytes); return { inputs: strings(list, 1), outputs: strings(list, 2), op: text.decode(firstBytes(list, 4) ?? new Uint8Array()) }; }

const supported = new Set<Operator>(["Add", "MatMul", "Concat", "Relu", "Conv"]);

export interface RehydrationResult { graph: GraphState; unsupported: string[]; }

export function rehydrateOnnx(bytes: Uint8Array): RehydrationResult {
  const model = fields(bytes); const graphBytes = firstBytes(model, 7); if (!graphBytes) throw new Error("No GraphProto was found in this ONNX model.");
  const graphFields = fields(graphBytes); const initializers = graphFields.filter((item) => item.field === 5 && item.value instanceof Uint8Array).map((item) => parseInitializer(item.value as Uint8Array));
  const valueInfos = graphFields.filter((item) => (item.field === 11 || item.field === 12) && item.value instanceof Uint8Array).map((item) => parseValueInfo(item.value as Uint8Array));
  const shapes = new Map(valueInfos.map((value) => [value.name, value.shape])); initializers.forEach((value) => shapes.set(value.name, value.shape));
  const parsed = graphFields.filter((item) => item.field === 1 && item.value instanceof Uint8Array).map((item) => parseNode(item.value as Uint8Array));
  const nodes: TensorNode[] = []; const nodeIds = new Set<string>(); const ensureNode = (id: string, index: number, fallback: number[] = [1, 4]) => {
    if (!id || nodeIds.has(id)) return; nodeIds.add(id);
    nodes.push({ id, label: id.toUpperCase().slice(0, 14), kind: "tensor", sourceMode: "line", shape: shapes.get(id) ?? fallback, position: { x: 0.18 + (index % 4) * 0.22, y: 0.28 + Math.floor(index / 4) * 0.22 }, stroke: [], telemetry: { sampleCount: 0, pressure: 0, velocity: 0, pathLength: 0, duration: 0 } });
  };
  const edges: TensorEdge[] = []; const unsupported: string[] = [];
  parsed.forEach((node, index) => {
    const output = node.outputs[0]; const source = node.inputs[0]; if (!source || !output) return;
    ensureNode(source, index); ensureNode(output, index + 1, shapes.get(output) ?? shapes.get(source));
    if (!supported.has(node.op as Operator)) { unsupported.push(node.op || "unnamed"); return; }
    edges.push({ id: crypto.randomUUID(), from: source, to: output, op: node.op as Operator, valid: true, outputShape: shapes.get(output) ?? shapes.get(source) });
  });
  if (!nodes.length) throw new Error("The model has no rehydratable value nodes in the supported subset.");
  return { graph: { nodes, edges, initializers }, unsupported: Array.from(new Set(unsupported)) };
}
