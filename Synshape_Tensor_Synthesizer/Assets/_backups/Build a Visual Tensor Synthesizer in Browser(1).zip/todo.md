# Tensor Synthesizer — Erweiterungsplan

- [x] Markt-, Namens- und Positionierungsrecherche zu visuellen ONNX-/Tensor-Werkzeugen dokumentieren.
- [x] Einen differenzierbaren Produktnamen und eine konkrete USP-Positionierung auswählen.
- [x] Ein vollständiges, responsive einsetzbares Marken- und Logopaket definieren und erzeugen.
- [x] Adaptive Intro-Sequenzen für Quer- und Hochformat umsetzen.
- [x] Vollbildmodus für den zentralen Tensor-Arbeitsbereich ergänzen.
- [x] About-Panel mit Micha-Attribution und Link zu https://g.dev/avx ergänzen.
- [x] Editierbare nD-Dimensionsformel und Knotenaktualisierung implementieren.
- [x] ONNX-Initialisierer importieren/exportieren und in die Raw-Protobuf-Serialisierung integrieren.
- [x] onnxruntime-web als optionale rein lokale Modellvalidierung integrieren.
- [x] README aktualisieren sowie Desktop-, Mobil- und Exportabläufe prüfen.
