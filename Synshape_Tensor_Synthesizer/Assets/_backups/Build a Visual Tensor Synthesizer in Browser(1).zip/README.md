# Synshape

> **Draw a surface. Resolve the graph.**

**Synshape** is a browser-native, gesture-native tensor authoring instrument. It converts pointer, touch, or pen telemetry into typed tensor descriptors, lets users route those descriptors through a directed acyclic graph, exposes shape incompatibilities before export, and serializes a raw ONNX protobuf without an application backend.

The product is positioned as **gesture-native tensor authoring**, rather than as a model viewer. This distinction matters because established tools such as Netron are designed to inspect existing ML models, while the ONNX ecosystem presents visualizers as a way to understand a model’s computational graph. Synshape instead starts before an ONNX artifact exists and treats spatial input as the authoring medium. [1] [2]

## Product model

The canonical graph remains inside browser memory. Nodes are drawn tensor structures or micro-RAG contexts; edges carry an inferred operation and a compatibility result. The visual workspace uses a WebGL field and an animation-frame canvas pipeline, preserving responsive pointer interaction while React maintains the higher-level semantic state.

| Layer | Responsibility | Browser-local behavior |
| --- | --- | --- |
| **Sensorik** | Captures X/Y, pressure, velocity, sample count, path length, and duration. | Pointer events are summarized to generate shape descriptors. |
| **Tensor synthesis** | Resolves line, surface, volume, nD, and micro-RAG input into Float32 tensor shapes. | Shape generation is deterministic and runs in-memory. |
| **Graph router** | Infers `Add`, `MatMul`, or `Concat` and prevents duplicate paths, ambiguous target inputs, and directed cycles. | Compatibility results appear immediately on the canvas. |
| **ONNX exporter** | Emits `ModelProto`, `GraphProto`, `NodeProto`, value information, typed shape information, and optional `TensorProto` initializers. | A raw `.onnx` binary is created in a local `Blob` download. |
| **Runtime check** | Loads the generated model through ONNX Runtime Web with the WebAssembly provider. | The model is not uploaded; the result only reflects local model-load acceptance. |

The ONNX design is strongly typed and uses protobuf to represent and serialize graph/model objects, which is why Synshape keeps names, shapes, and Float32 tensor declarations explicit throughout its exporter. [3]

## Brand system

The official product identity is **Synshape**. “Tensor Synthesizer” remains the descriptive product category, not a competing visible name. The signature mark is an asymmetric four-axis tensor knot: graphite planes surround a Tensor-Lime core with one cyan structural edge. The product wordmark uses **Space Grotesk**; shapes, operators, telemetry, and coordinates use **IBM Plex Mono**.

| Signal | Meaning | Color |
| --- | --- | --- |
| **Tensor Lime** | Valid route, resolved action, export-ready state | `#C8FF5A` |
| **Structural Cyan** | Tensor geometry, neutral topology, micro-RAG identity | `#75E5EF` |
| **Conflict Coral** | Illegal shape route or rejected state | `#FF8388` |
| **Graphite** | Quiet spatial field and instrument perimeter | `#061117` |

The generated tensor-knot asset is used at navigation, favicon, and launch scale. Dedicated 16:9 and 9:16 launch imagery lets the brand introduction preserve compositional contrast in landscape and portrait instead of treating mobile as a cropped desktop asset.

## Interaction guide

When the three-and-a-half-second entry sequence completes, select a tensor mode and draw on the center field. A line generates `[batch, length]`; a surface generates `[batch, height, width]`; a volume adds a depth proxy; and nD mode uses an editable dimension formula such as `2 × 24 × 32 × 16 × 64`. In route mode, drag from one node to another. Synshape resolves the candidate operation, marks an illegal shape route in coral, and blocks cycle creation before it changes the DAG.

The **Focus field** control, as well as the compact control in the header, requests browser fullscreen for the central spatial stage. The header’s information control opens the product About panel, including the creator credit: [Micha | g.dev/avx](https://g.dev/avx).

Initializer exchange uses a small explicit JSON container:

```json
{
  "format": "synshape.initializers/v1",
  "initializers": [
    {
      "name": "kernel-weight__basis",
      "shape": [32, 64],
      "values": [0.01, -0.03]
    }
  ]
}
```

Every initializer is checked for a positive integer shape and a value count matching the product of its dimensions before it is accepted. On ONNX export, accepted values are emitted as a named Float32 `TensorProto` initializer.

## Local runtime verification

Selecting **Validate locally** serializes the current graph, dynamically loads ONNX Runtime Web, and creates a local inference session with the WebAssembly execution provider. ONNX Runtime Web documents WebAssembly as broadly supported across its browser matrix; it also documents WebGPU and experimental WebNN entry points. Synshape deliberately treats the present check as a **load-validation gate**, not an accuracy or performance benchmark. [4]

## Development

The application is a static React 19 + TypeScript + Tailwind 4 project. It has no product backend, database, or secret-dependent feature.

```bash
pnpm install
pnpm dev
pnpm run check
pnpm exec vitest run client/src/lib/tensor-onnx.test.ts
pnpm run build
```

The existing automated checks cover matrix-contraction inference, directed-cycle protection, and raw ONNX byte construction. The production build also includes the WASM binary required for optional local ONNX Runtime Web model loading.

## Naming research note

The product name was chosen after a preliminary marketing-oriented digital collision screen. It rejected obvious directions such as **Tensora** and **Tensorium** because active AI/software results were discoverable, and avoided **Tensym** due to the IEEE TENSYMP association. **Synshape** is a portmanteau of synthesis and shape, directly naming the product transformation. This is not trademark, corporate-name, or domain clearance; commercial use should be preceded by qualified searches in the jurisdictions and classes that matter to the owner.

## References

[1]: https://onnx.ai/supported-tools.html "ONNX — Supported Tools"
[2]: https://github.com/lutzroeder/Netron "Netron — Visualizer for neural network, deep learning and machine learning models"
[3]: https://onnx.ai/onnx/intro/python.html "ONNX — Model construction and serialization"
[4]: https://onnxruntime.ai/docs/get-started/with-javascript/web.html "ONNX Runtime Web — Get started"
